../hgm_w-n --idata tmp-idata3.txt --dataf aa
diff aa* tmp-data3-out.txt
echo "Remove aa-* if there is no difference."