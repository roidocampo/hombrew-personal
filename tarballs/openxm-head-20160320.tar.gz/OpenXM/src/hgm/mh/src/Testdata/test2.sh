../hgm_w-n --idata tmp-idata2.txt --dataf bb
diff bb* tmp-data2-out.txt
echo "Remove bb-* if there is no difference."
