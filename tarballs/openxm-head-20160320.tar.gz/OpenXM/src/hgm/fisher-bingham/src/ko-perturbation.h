double *perturbation(const double v[], double error[]);
void perturbation_init(int l,  double e);
void perturbation_free(void);

