#ifndef _KO_TIME
#define _KO_TIME

void ko_time_init(int n, ...);
void ko_time_print(void);
void ko_time_start(char *s);
void ko_time_end(char *s);

#endif
