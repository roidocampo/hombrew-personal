ln -s ../glicosa.c .
ln -s ../glray3.c .
ln -s ../mygl.h .

