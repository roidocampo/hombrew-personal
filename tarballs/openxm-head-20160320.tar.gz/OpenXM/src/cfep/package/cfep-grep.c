#include <stdio.h>
#include "ox_pathfinder.h"

/*
  cfep-grep --inHex key   (key $B$d(B folder $BL>Ey$9$Y$F(B 16$B?J?t(B, utf8 $B$G(B) 
  cfep-grep --grep key    (grep $B$N$_(B)
  cfep-grep --mdfind key  (mdfind $B$N$_(B. spotlight)
  cfep-grep --mdfind --pdf key  (mdfind, kind:pdf $B$N$_(B. spotlight)
  cfep-grep --folder folderName (default folder $B0J30$N8!:w(B)

  grep $B$N(B default folder $B$O(B  $B%W%m%0%i%`Cf$K(B $BDj?tJ8;zNs$NG[Ns$H$7$FKd$a9~$s$G$"$k(B.
    ${OpenXM_HOME}/doc/cfep/html-ja_JP.eucJP/html-ja
    ${OpenXM_HOME}/doc/cfep/html-ja_JP.eucJP/html-exp-ja
  spotlight $B$N(B default folder $B$O(B
    ${OpenXM_HOME}/doc/cfep

  $B=PNO$O(B utf8 $B$N(B html $B%U%!%$%k(B.
   google $B%D!<%k%P!<$,$D$$$F$k$H$$$$$M(B. cite: $B$O(B OpenXM $B$H(B RA journal.
*/

main(int argc, char *argv[]) {

}
