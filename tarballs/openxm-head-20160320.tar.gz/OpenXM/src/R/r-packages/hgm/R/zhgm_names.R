hgm.so3nc<-hgm.tk.so3nc
hgm.ncso3<-hgm.tk.so3nc
hgm.normalizingConstantOfFisherDistributionOnSO3<-hgm.tk.so3nc
hgm.pwishart<-hgm.tk.pwishart
hgm.ncorthant<-hgm.ko.ncorthant
hgm.normalizingConstantOfOrthant<-hgm.ko.ncorthant
hgm.Rhgm<-hgm.se.hgm
hgm.Rhgm.demo1<-hgm.se.demo1
hgm.ncBingham<-hgm.se.hgm.Bingham
hgm.normalizingConstantOfBinghamDistribution<-hgm.se.hgm.Bingham

