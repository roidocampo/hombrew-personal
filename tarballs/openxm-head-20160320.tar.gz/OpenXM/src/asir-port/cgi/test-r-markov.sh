#!/bin/bash
# r_markov([[1,2,-3]])
CONTENT_LENGTH=51 ./cgi-asir-r-markov.sh <test-r-markov.txt
