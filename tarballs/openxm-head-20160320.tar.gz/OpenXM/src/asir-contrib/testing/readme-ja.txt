$B$3$N(B directory $B$K$O<!$N%U%!%$%k$r$*$/(B.

(1) asir $B$K?7$7$/AH$_9~$`(B($B$+$b$7$l$J$$(B) builtin $B4X?tEy$r(B
   $B%f!<%68@8l$G%F%9%H$9$k%U%!%$%k$d%I%-%e%a%s%H$r$*$/(B.
(2) packages $B$K$$$l$k$+$I$&$+$^$@$o$+$i$J$$$,(B cvs $B$K$*$$$F$*$/$H$h$$$b$N(B.


$OpenXM: OpenXM/src/asir-contrib/testing/readme-ja.txt,v 1.1 2005/03/30 05:10:40 takayama Exp $