/*
 * $OpenXM: OpenXM/src/OpenMath/OM2OXM.java,v 1.26 2000/10/11 08:32:13 ohara Exp $
 */

/**
 * $B$3$N%/%i%9$G$O0J2<$N(B BNF $B$GI=$5$l$k9=J82r@O$r<BAu$7$F$$$k(B
 * expr -> stag [expr | immediate]* etag
 * immediate -> INTEGER
 *            | SYMBOL
 * stag -> '<' SYMBOL '>'
 * etag -> '<' '/' SYMBOL '>'
 * $B=*C<5-9f(B: INTEGER, SYMBOL, '<', '/', '>'
 * $BHs=*C<5-9f(B: expr, stag, etag, immediate
 * $B3+;O5-9f(B: expr
 *
 * $B0J2<$N4X?t$r;HMQ(B:
 * public void send(OutputStream os); - buffer $B$K$"$k(B OX message $B$rAw?.$9$k(B.
 * public int parse(); - $B9=J82r@O$r3+;O$9$k(B.
 * private int parse_expr();       - parser $B$N(B expr $BItJ,(B
 * private Attribute parse_stag(); - parser $B$N(B stag $BItJ,(B
 * private void parse_etag(Attribute tag,int argnum); - parser $B$N(B etag $BItJ,(B
 * private int parse_immediate();  - parser $B$N(B immediate $BItJ,(B
 * private void parse_error(String mesg); - parser $B$N(B error $B$rI=<($7$F=*N;$9$k(B
 * public static void main(String[] args); - main $B4X?t(B.
 *
 * $B0J2<$NJQ?t$r;HMQ(B:
 * Attribute Attribute; - $B;z6g2r@O4o$r8F$S=P$7(B, $B$=$NB0@-CM$rJ]B8$7$F$*$/(B
 * int token; - $B8=:_FI$_9~$s$G$$$k(B token $B$rJ]B8$7$F$*$/$N$K;HMQ(B.
 * CellStack stack; - $B%;%^%s%F%#%C%/%9$N%A%'%C%/$K;H$&FbIt%9%?%C%/(B.
 * ByteArrayOutputStream buffer; - oxasir $B$KAw?.$9$k$^$($K%G!<%?$rN/$a$F$*$/(B
 */

import java.io.*;
import java.net.*;
import java.util.Vector;
import ORG.openxm.tam.*;

final class OM2OXM implements Runnable{
  private PushbackInputStream is;
  private String attribute;
  private int token = TT_NULL;
  private boolean lexPushbackFlag = false;
  private OpenXM asir; // for debug
  protected boolean debug = false; // for debug message

  // Token Type for lexical analyzer
  final static int TT_NULL      = 0;
  final static int TT_String    = -1;
  final static int TT_StartTag  = -2;
  final static int TT_EndTag    = -3;
  final static int TT_SingleTag = -4;

  public void run(){ // for debug
    //$B%5!<%PB&$+$iAw?.$5$l$?J8;zNs$r<u?.$7$^$9!#(B
    try{
      while(true){
	OXmessage message = asir.receive();

	if(message.getTag() == OXmessage.OX_DATA){
	  System.err.println("=> "+ CMO2OM((CMO)message.getBody()));
          break;
	}
      }
    }catch(IOException e){}
  }

  public static String CMO2OM(CMO cmo){
    return "<OMOBJ>"+ CMO2OM_sub(cmo) +"</OMOBJ>";
  }

  private static String CMO2OM_sub(CMO cmo) throws NumberFormatException{
    String ret = "";

    switch(cmo.getDISCRIMINATOR()){
    case CMO.NULL:
      return "<OMI>0</OMI>";

    case CMO.INT32:
      return "<OMI>"+ ((CMO_INT32)cmo).intValue() +"</OMI>";

      // case CMO.DATUM:

    case CMO.STRING:
      return "<OMSTR>"+ ((CMO_STRING)cmo).getString() +"</OMSTR>";

    case CMO.LIST:
      ret += "<OMA><OMS name=\"list\" cd=\"basic\"/>";
      {
	CMO ob[] = ((CMO_LIST)cmo).getElements();

	for(int i=0;i<ob.length;i++){
	  ret += CMO2OM_sub(ob[i]);
	}
      }
      ret += "</OMA>";
      return ret;

    case CMO.MONOMIAL32:
      ret += "<OMA><OMS name=\"Monom\" cd=\"poly\"/>";
      ret += CMO2OM_sub(((CMO_MONOMIAL32)cmo).getCoefficient());
      for(int i=0;i<((CMO_MONOMIAL32)cmo).getDegree().length;i++){
	ret += "<OMI>"+ ((CMO_MONOMIAL32)cmo).getDegree()[i] +"</OMI>";
      }
      ret += "</OMA>";
      return ret;

    case CMO.ZZ:
      return "<OMI>"+ ((CMO_ZZ)cmo).BigIntValue() +"</OMI>";

    case CMO.QQ:
      return "<OMA><OMS name=\"over\" cd=\"basic\"/>"+
	CMO2OM_sub(((CMO_QQ)cmo).getBunshi())+
	CMO2OM_sub(((CMO_QQ)cmo).getBunbo())+
	"</OMA>";

    case CMO.ZERO:
      return "<OMI> 0 </OMI>";

      // case CMO.DMS:

    case CMO.DMS_GENERIC:
      ret += "<OMA><OMS name=\"PolyRing\" cd=\"poly\"/>";
      ret += "<OMI>2</OMI></OMA>";
      return ret;

    case CMO.RECURSIVE_POLYNOMIAL:
      return CMO2OM_CoefficientOfRecursivePOLYNOMIAL(((CMO_RECURSIVE_POLYNOMIAL)cmo).getPolynomial(),((CMO_RECURSIVE_POLYNOMIAL)cmo).getVariables());

    case CMO.DISTRIBUTED_POLYNOMIAL:
      ret += "<OMA><OMS name=\"DMP\" cd=\"poly\"/>";
      ret += CMO2OM_sub(((CMO_DISTRIBUTED_POLYNOMIAL)cmo).getRing());
      ret += "<OMA><OMS name=\"SDMP\" cd=\"poly\"/>";
      for(int i=0;i<((CMO_DISTRIBUTED_POLYNOMIAL)cmo).getMonomials().length;
	  i++){
	ret += CMO2OM_sub(((CMO_DISTRIBUTED_POLYNOMIAL)cmo).getMonomials()[i]);
      }
      ret += "</OMA></OMA>";
      return ret;

      //case CMO.POLYNOMIAL_IN_ONE_VARIABLE:

    case CMO.BIGFLOAT:
      ret += "<OMA><OMS name=\"times\" cd=\"basic\"/>";
      ret += CMO2OM_sub(((CMO_BIGFLOAT)cmo).getSyosubu());
      ret += "<OMA><OMS name=\"power\" cd=\"basic\"/>";
      ret += "<OMI>2</OMI>";
      ret += CMO2OM_sub(((CMO_BIGFLOAT)cmo).getShisubu());
      ret += "</OMA></OMA>";
      return ret;

    case CMO.INDETERMINATE:
      return "<OMV name=\""+ ((CMO_INDETERMINATE)cmo).getString() +"\"/>";

    case CMO.TREE:
      ret += "<OMA><OMS name=\""+ ((CMO_TREE)cmo).getName() +"\" cd=\""+
	((CMO_TREE)cmo).getCDName() +"\"/>";
      for(int i=0;i<((CMO_TREE)cmo).getLeaves().getElements().length;i++){
	ret += CMO2OM_sub(((CMO_TREE)cmo).getLeaves().getElements()[i]);
      }
      ret += "</OMA>";
      return ret;

    default:
      //return "<OMSTR>"+ cmo.toCMOexpression() +"</OMSTR>";
    }

    throw new NumberFormatException("unknown convert way:"+
				    cmo.toCMOexpression());
  }

  private static String CMO2OM_CoefficientOfRecursivePOLYNOMIAL(CMO cmo,CMO_LIST variables){
    CMO_POLYNOMIAL_IN_ONE_VARIABLE poly;
    String ret = "",variable;

    if(!(cmo instanceof CMO_POLYNOMIAL_IN_ONE_VARIABLE)){
      return CMO2OM_sub(cmo);
    }

    poly = (CMO_POLYNOMIAL_IN_ONE_VARIABLE)cmo;
    variable = CMO2OM_sub(variables.getElements()[poly.getVariable()]);
 
   for(int i=0;i<poly.getDegrees().length;i++){
      String mono;

      mono = "<OMA><OMS name=\"times\" cd=\"basic\"/>"+
	"<OMA><OMS name=\"power\" cd=\"basic\"/>"+
	variable +"<OMI>"+ poly.getDegrees()[i] +"</OMI></OMA>"+
	CMO2OM_CoefficientOfRecursivePOLYNOMIAL(poly.getCoefficients()[i],
						variables)
	+"</OMA>";
      if(i==0){
	ret = mono;
      }else{
	ret = "<OMA><OMS name=\"plus\" cd=\"basic\"/>"+ ret + mono +"</OMA>";
      }
    }

   return ret;
  }

  private boolean isSpace(int ch){ // use from lex
    return (ch==' ' || ch=='\t' || ch=='\n' || ch=='\r');
  }

  private int skipSpace() throws IOException{ // use from lex
    int ch;

    do{
      ch = is.read();
    }while(isSpace(ch));
    is.unread(ch);

    return ch;
  }

  private void pushbackLex(){
    if(lexPushbackFlag){
      System.err.println("lex pushback error!");
    }
    lexPushbackFlag = true;
  }

  private int readNextToken() throws IOException{ // lexical analyzer
    String buf = "";
    int ch;

    if(lexPushbackFlag){
      lexPushbackFlag = false;
      return token;
    }

    token = TT_NULL;
    attribute = "";
    skipSpace();
    ch = is.read();

    if(ch == '<'){ // for tag
      ch = skipSpace();
      if(ch == '/'){
	is.read();
	token = TT_EndTag;
	skipSpace();
      }else{
	token = TT_StartTag;
      }
      while((ch = is.read()) != '>' && ch != '/' && ch != -1){
	if(isSpace(ch)){
	  if((ch = skipSpace()) != '>' && ch != '/'){
	    buf += " ";
	  }
	  continue;
	}

	buf += Character.toUpperCase((char)ch);

	if(ch == '"'){
	  do{
	    ch = is.read();
	    buf += (char)ch;
	  }while(ch != '"' && ch != -1);
	}
      }
      if(ch == '>'){ // for StartTag and EndTag
	attribute = buf;
	return token;
      }else if(ch == '/'){
	skipSpace();
	if((ch = is.read()) == '>'){ // for SingleTag
	  attribute = buf;
	  return token = TT_SingleTag;
	}
      }
      return token = TT_NULL;
    }else if(ch != -1){
      is.unread(ch);
      while((ch = is.read()) != '<' && ch != -1){
	debug("debug: "+ch);
	if(isSpace(ch)){
	  String spaces = String.valueOf((char)ch);

	  while(isSpace(ch = is.read())){
	    spaces += (char)ch;
	  }
	  if(ch != '<' && ch != -1){
	    buf += spaces;
	  }
	  is.unread(ch);
	}else{
	  buf += (char)ch;
	}
      }
      is.unread(ch);

      attribute = buf;
      return token = TT_String;
    }

    return token = TT_NULL;
  }

  private boolean exceptTokenTypeInParse(int type) throws IOException{
    // use from parse
    if(readNextToken() != type){
      parse_error("We expect type :'"+ type
		  +"', but we got type :'"+ token +"'("+ attribute +").");
    }
    //debug(":"+token+":"+attribute+":"+type);
    return true;
  }

  public CMO parse(InputStream stream) throws IOException{
    // start -> '<OMOBJ>' object '</OMOBJ>'
    CMO ret;

    is = new PushbackInputStream(stream);

    exceptTokenTypeInParse(TT_StartTag);
    if(!attribute.equals("OMOBJ")){
      parse_error("We expect '<OMOBJ>'.");
    }

    ret = parse_object();

    exceptTokenTypeInParse(TT_EndTag);
    if(!attribute.equals("OMOBJ")){
      parse_error("We expect '</OMOBJ>'.");
    }

    return ret;
  }

  private CMO parse_object() throws IOException{
    // object -> variable
    //         | '<OMI>' S? integer S? '</OMI>'
    //         | '<OMSTR>' S? utf7 S? '</OMSTR>'
    //         | '<OMA>' S? symbol S? objects S? '</OMA>'
    CMO ret;

    if(readNextToken() != TT_StartTag && token != TT_SingleTag){
      parse_error("We expect '<OMI> or '<OMA>' or '<OMV>'.");
    }

    if(attribute.startsWith("OMV")){
      pushbackLex();
      ret = parse_variable();
    }else if(attribute.equals("OMI")){
      pushbackLex();
      ret = parse_OMI();
    }else if(attribute.equals("OMSTR")){
      pushbackLex();
      ret = parse_OMSTR();
    }else if(attribute.equals("OMA")){
      String name,cdname;
      int argnum = 0;

      name = parse_symbol();

      if(name.equals("DMP")){
	ret = parse_symb_DMP();
	debug("poly: "+ret);
      }else{
	CMO[] leaves = parse_objects();

	if(name.equals("list")){
	  ret = new CMO_LIST(leaves);
	}else if(name.equals("over") && leaves.length==2
		 && leaves[0] instanceof CMO_ZZ
		 && leaves[1] instanceof CMO_ZZ){
	  ret = new CMO_QQ((CMO_ZZ)leaves[0],(CMO_ZZ)leaves[1]);
	}else{
	  ret = new CMO_TREE(name,"basic",new CMO_LIST(leaves));
	}
      }

      exceptTokenTypeInParse(TT_EndTag);
      if(!attribute.equals("OMA")){
	parse_error("We expect '</OMA>'.");
      }
    }else{
      parse_error("We expect '<OMI> or '<OMA>' or '<OMV>'.");
      ret = null;
    }

    return ret;
  }

  private CMO_ZZ parse_OMI() throws IOException{
    CMO_ZZ ret;

    exceptTokenTypeInParse(TT_StartTag);
    if(!attribute.equals("OMI")){
      parse_error("We expect '<OMI>'.");
    }

    ret = (CMO_ZZ)parse_integer();

    exceptTokenTypeInParse(TT_EndTag);
    if(!attribute.equals("OMI")){
      parse_error("We expect '</OMI>'.");
    }

    return ret;
  }

  private CMO_STRING parse_OMSTR() throws IOException{
    CMO_STRING ret;

    exceptTokenTypeInParse(TT_StartTag);
    if(!attribute.equals("OMSTR")){
      parse_error("We expect '<OMSTR>'.");
    }

    if(readNextToken() == TT_String){
      //ret = (CMO_STRING)parse_utf7();
      ret = new CMO_STRING(attribute);
    }else{
      ret = new CMO_STRING("");
      pushbackLex();
    }

    exceptTokenTypeInParse(TT_EndTag);
    if(!attribute.equals("OMSTR")){
      parse_error("We expect '</OMSTR>'.");
    }

    return ret;
  }

  private CMO parse_symb_DMP() throws IOException{
    parse_object();
    return new CMO_DISTRIBUTED_POLYNOMIAL(new CMO_DMS_GENERIC(),
					  parse_symb_SDMP());
  }

  private CMO_MONOMIAL32[] parse_symb_SDMP() throws IOException{
    Vector mono = new Vector();
    CMO_MONOMIAL32[] ret;

    exceptTokenTypeInParse(TT_StartTag);
    if(!attribute.equals("OMA")){
      parse_error("We expect '<OMA>'.");
    }

    if(!parse_symbol().equals("SDMP")){
      parse_error("We expect '<SDMP>'");
    }

    while(readNextToken() != TT_EndTag){
      pushbackLex();
      mono.addElement(parse_symb_Monom());
    }

    if(!attribute.equals("OMA")){
      parse_error("We expect '</OMA>'.");
    }

    ret = new CMO_MONOMIAL32[mono.size()];
    mono.copyInto((Object[])ret);

    return ret;
  }

  private CMO_MONOMIAL32 parse_symb_Monom() throws IOException{
    Vector degree = new Vector();
    CMO coefficient;
    int[] array;

    exceptTokenTypeInParse(TT_StartTag);
    if(!attribute.equals("OMA")){
      parse_error("We expect '<OMA>'.");
    }

    if(!parse_symbol().equals("Monom")){
      parse_error("We expect '<Monom>'");
    }

    coefficient = parse_object();
    if(!(coefficient instanceof CMO_ZZ
	 || coefficient instanceof CMO_QQ
	 || coefficient instanceof CMO_INT32
	 || coefficient instanceof CMO_ZERO)){
      parse_error("the coefficient of Monomials must be integer or rational.");
    }

    while(readNextToken() != TT_EndTag){
      pushbackLex();
      degree.addElement(parse_OMI());
    }

    if(!attribute.equals("OMA")){
      parse_error("We expect '<OMA>'.");
    }

    array = new int[degree.size()];
    for(int i=0;i<array.length;i++){
      array[i] = ((CMO_ZZ)degree.elementAt(i)).intValue();
    }

    //debug("monom: "+ new CMO_MONOMIAL32(array,coefficient));
    return new CMO_MONOMIAL32(array,coefficient);
  }

  private CMO[] parse_objects() throws IOException{
    Vector objects = new Vector();
    CMO[] array;

    while(readNextToken() != TT_EndTag){
      pushbackLex();
      objects.addElement(parse_object());
    }
    pushbackLex();

    objects.trimToSize();
    array = new CMO[objects.size()];
    objects.copyInto((Object[])array);

    debug("debug :"+ new CMO_LIST(array));
    return array;
  }

  private String parse_symbol() throws IOException{
    // symbname $B$rJV$9(B
    String ret = "";
    StreamTokenizer para;

    exceptTokenTypeInParse(TT_SingleTag);

    para = new StreamTokenizer(new StringReader(attribute));
    para.resetSyntax();
    para.wordChars('A','Z');
    para.wordChars('a','z');
    para.wordChars('0','9');
    para.wordChars('\u00A0','\u00FF');
    para.whitespaceChars('\u0000','\u0020');
    para.quoteChar('"');
    para.eolIsSignificant(false);
    para.lowerCaseMode(true);
    para.slashStarComments(false);
    para.slashSlashComments(false);
    para.ordinaryChar('=');

    if(para.nextToken() != StreamTokenizer.TT_WORD
       || !para.sval.equalsIgnoreCase("OMS")){
      parse_error("We expect '<OMS>', but '"+ para.sval +"'.");
    }

    if(para.nextToken() != StreamTokenizer.TT_WORD){
      parse_error("We expect 'name' or 'cd'.");
    }
    if(para.sval.equals("name")){
      if(para.nextToken() != '='){
	parse_error("We expect '='.");
      }
      if(para.nextToken() != '"'){
	parse_error("We expect '\"'.");
      }
      ret = parse_symbname(para.sval);

      if(para.nextToken() != StreamTokenizer.TT_WORD
	 || !para.sval.equals("cd")){
	parse_error("We expect 'cd'.");
      }
      if(para.nextToken() != '='){
	parse_error("We expect '='.");
      }
      if(para.nextToken() != '"'){
	parse_error("We expect '\"'.");
      }
      parse_cdname(para.sval);

    }else if(para.sval.equals("cd")){
      if(para.nextToken() != '='){
	parse_error("We expect '='.");
      }
      if(para.nextToken() != '"'){
	parse_error("We expect '\"'.");
      }
      parse_cdname(para.sval);

      if(para.nextToken() != StreamTokenizer.TT_WORD
	 || !para.sval.equals("name")){
	parse_error("We expect 'cd'.");
      }
      if(para.nextToken() != '='){
	parse_error("We expect '='.");
      }
      if(para.nextToken() != '"'){
	parse_error("We expect '\"'.");
      }
      ret = parse_symbname(para.sval);

    }else{
      parse_error("We expect 'name' or 'cd'.");
    }

    if(para.nextToken() != StreamTokenizer.TT_EOF){
      parse_error("We expect '/>'.");
    }

    return ret;
  }

  private CMO parse_integer() throws IOException{
    //Attribute integer = new Attribute(value);
    String str;
    int i=0;

    exceptTokenTypeInParse(TT_String);
    str = attribute;

    if(str.charAt(i)=='-'){
      i++;
    }
    if(str.length()>=i+2 && str.charAt(i)=='x'){ // for HEX
      String strhex = str.substring(0,i) + str.substring(i+1);
      for(i++;i<str.length();i++){
	if("0123456789ABCDEF".indexOf((int)str.charAt(i)) == -1){
	  parse_error("We expect integer.");
	}
      }
      // 10 $B?J?t$KJQ49(B
      str = (new java.math.BigInteger(strhex,16)).toString();
    }else if(str.length()>=i+1){ // for DEC
      for(;i<str.length();i++){
	if("0123456789".indexOf((int)str.charAt(i)) == -1){
	  parse_error("We expect integer.");
	}
      }
    }else{
      parse_error("We expect integer.");
    }

    debug("ZZ: "+ str);
    return new CMO_ZZ(str);
  }

  private CMO parse_variable() throws IOException{
    StreamTokenizer para;
    CMO ret;

    exceptTokenTypeInParse(TT_SingleTag);

    para = new StreamTokenizer(new StringReader(attribute));
    para.resetSyntax();
    para.wordChars('A','Z');
    para.wordChars('a','z');
    para.wordChars('0','9');
    para.wordChars('\u00A0','\u00FF');
    para.whitespaceChars('\u0000','\u0020');
    para.quoteChar('"');
    para.eolIsSignificant(false);
    para.lowerCaseMode(true);
    para.slashStarComments(false);
    para.slashSlashComments(false);
    para.ordinaryChar('=');

    if(para.nextToken() != StreamTokenizer.TT_WORD
       || !para.sval.equalsIgnoreCase("OMV")){
      parse_error("We expect '<OMV>'.");
    }

    if(para.nextToken() != StreamTokenizer.TT_WORD
       || !para.sval.equals("name")){
      parse_error("We expect 'name', but obtain '"+ para.sval +"'.");
    }
    if(para.nextToken() != '='){
      parse_error("We expect '='.");
    }
    if(para.nextToken() != '"'){
      parse_error("We expect '\"'.");
    }
    ret = new CMO_INDETERMINATE(parse_varname(para.sval));

    if(para.nextToken() != StreamTokenizer.TT_EOF){
      parse_error("We expect '/>'.");
    }

    return ret;
  }

  private String parse_varname(String str){
    String words = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
      + "0123456789+='(),-./:?!#$%*;@[]^_`{|}";

    for(int i=0;i<str.length();i++){
      if(words.indexOf((int)str.charAt(i))==-1){
	parse_error("string \""+ str +"\" is not varname.");
      }
    }

    return str;
  }

  private String parse_cdname(String str){
    String alphabet = "abcdefghijklmnopqrstuvwxyz";
    int i=0;

    if(alphabet.indexOf((int)str.charAt(i))==-1){
      parse_error("cdname \""+ str +"\" must begin small alphabet.");
    }
    for(i++;i<str.length();i++){
      if((alphabet + "0123456789_").indexOf((int)str.charAt(i))==-1){
	parse_error("string \""+ str +"\" is not cdname.");
      }
    }

    return str;
  }

  private String parse_symbname(String str) throws IOException{
    String Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    int i=0;

    if(Alphabet.indexOf((int)str.charAt(i))==-1){
      parse_error("symbname \""+ str +"\" must begin alphabet.");
    }
    for(i++;i<str.length();i++){
      if((Alphabet + "0123456789_").indexOf((int)str.charAt(i))==-1){
	parse_error("string \""+ str +"\" is not symbname.");
      }
    }

    return str;
  }

  private void parse_error(String mesg) throws NumberFormatException{
    String ret;

    ret = mesg +"\n";
    ret += "error occuered before that :";
    try{
      for(int i=0;i<40;i++){
	ret += (char)is.read();
      }
    }catch(IOException e){}
    ret += "\n";

    throw new NumberFormatException(ret);
  }

  private void debug(String str){
    if(debug){
      System.err.println(str);
    }
  }

  public static void main(String[] argv) throws IOException{
    OM2OXM P = new OM2OXM();
    OpenXM asir;
    String host = "localhost";
    int CtrlPort = 1200,StreamPort = 1300;

    for(int i=0;i<argv.length;i++){
      if(argv[i].equals("-h")){
	System.err.println("");
	System.exit(0);
      }else if(argv[i].equals("-host")){
	host = argv[++i];
      }else if(argv[i].equals("-data")){
	StreamPort = Integer.valueOf(argv[++i]).intValue();
      }else if(argv[i].equals("-control")){
	CtrlPort = Integer.valueOf(argv[++i]).intValue();
      }else{
	System.err.println("unknown option :"+ argv[i]);
	System.exit(1);
      }
    }

    try{
      asir = new OpenXM(host,CtrlPort,StreamPort);
      asir.send(new SM(SM.SM_mathcap));
    }catch(UnknownHostException e){
      System.err.println("host unknown.");
      System.err.println(e.getMessage());
      return;
    }catch(IOException e){
      System.err.println("connection failed.");
      System.err.println("IOException occuer !!");
      System.err.println(e.getMessage());
      return;
    }catch(MathcapViolation e){
      System.err.println("MathcapViolation !!");
      System.err.println(e.getMessage());
      return;
    }

    P.asir = asir;
    new Thread(P).start();
    System.err.println("start");

    try{
      //P.value = new Attribute(System.in);

      //$B%5!<%PB&$+$iAw?.$5$l$?J8;zNs$r<u?.$7$^$9!#(B
      while(true){
	try{
	  CMO obj = P.parse(System.in);
	  asir.send(obj);
	  asir.send(new SM(SM.SM_popCMO));
	}catch(NumberFormatException e){
	  System.err.println(e.getMessage());
	}catch(MathcapViolation e){
	  System.err.println(e.getMessage());
	}
      }

    }catch(IOException e){
      e.printStackTrace();
    }finally{
      System.err.println("breaking...");
    }
  }
}
