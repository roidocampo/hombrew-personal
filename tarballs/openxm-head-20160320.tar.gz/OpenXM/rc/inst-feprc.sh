# $OpenXM: OpenXM/rc/inst-feprc.sh,v 1.1 2010/02/06 00:38:12 takayama Exp $
if [ ! -f $HOME/.feprc ]; then 
   echo "Installing .feprc" ; cp $OpenXM_HOME/rc/feprc $HOME/.feprc 
fi
